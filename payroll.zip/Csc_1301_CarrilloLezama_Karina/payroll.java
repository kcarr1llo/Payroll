
import java.util.Scanner;
import java.math.RoundingMode;
import java.text.DecimalFormat;
/*
 * Karina Carrillo Lezama
 * Homework 5
 * 
 * Payroll Program
 */


public class payroll {
	private static DecimalFormat df2 = new DecimalFormat("#.###");
	
	public static void main(String[] args) {
		String employeeName;
		int hours;
		double payRate;
		double taxRate;
		double grossPay;
		double grossPayAfterTax;
		double taxDeducted;
		
		Scanner input = new Scanner(System.in);
		
		System.out.println("\tEnter employee name:");
		employeeName = input.nextLine();
		System.out.println("\tEnter hours worked:");
		hours = input.nextInt();
		System.out.println("\tEnter hourly pay rate:");
		payRate = input.nextDouble();
		System.out.println("\tEnter tax rate:");
		taxRate = input.nextDouble();
		
		grossPay = hours * payRate;
		taxDeducted = grossPay * taxRate;
		grossPayAfterTax = grossPay - taxDeducted;
		
		System.out.println("\tEmployee name: "+ employeeName);
		System.out.println("\tHours worked: "+ hours);
		System.out.println("\tHourly rate: "+ payRate);
		System.out.println("\tGross Pay: "+ df2.format(grossPay));
		System.out.println("\tTax Deducted: "+ df2.format(taxDeducted));
		System.out.println("\tNet pay: "+ df2.format(grossPayAfterTax));
		
		
		
	}

}


